/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./dist/*.{html,js}"],
  theme: {
  
    extend: {
      colors: {
        'rasara-blue': '#e31305',
        'rasara-green': '#009e2a',
      },
      fontFamily:{
        'vigaRasara':['Viga', 'sans-serif'],
        'oswaldRasara':['Oswald', 'sans-serif'],
      }
    },
  },
  plugins: [],
}




